-- DropIndex
DROP INDEX "Farmer_cpfCnpj_key";
